# Feladat:

1. Hozz létre egy új repot. A repo neve legyen a "Gyakorlás0320" és legyen publikus. Tartozzon hozzá egy Readme fájl is. 
2. Klónozd le a repot egy helyi tárolóba(local)
3. Ebben a tárolóban hozz létre egy HTML fájlt, a megfelelő Bootstrap hivatkozásokkal. 
4. Készíts róla egy pillanatképet, amelyet a megfelelő módon előkészítesz a feltöltésre, a "html fájl létrehozva" szöveggel. 
5. A weblapon készíts egy két oszlopból álló rácsrendszert. Az egyik 3 egységnyi legyen míg a másik töltse ki a hiányzó részt, mind kettő közepes és nagy képernyőfelbontásbán. 
6. Mentsd el ezt a változtatást is a "Rácsrendszer kialakítva" szöveggel. 
7. A nagyobb tárolóba helyezz el egy képet, amely a megfelelő Bootstrap osztály segítségével legyen alkalmazkodó(responsive), a kisebbe pedig egy leírást, amely a projektre jellemző. Ezt formázd, színezd egy általad választott Bootstrap osztállyal. 
8. Ezt a változtatást mentsd el a "kép hozzáadva" szöveggel.
9. A Readme fájlba másold be a feladatleírást.  
10. Töltsd a kész projektet  a Githubra.